/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Cliente;

import javax.ejb.Remote;

/**
 *
 * @author 30917921
 */
@Remote
public interface InterCliente {

    public abstract String setName(String nome);

    public abstract String setEmail(String email);

    public abstract int setCod_Cli(int cod_cli);

    public abstract int setRg(int rg);
}
