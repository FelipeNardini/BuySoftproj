/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Cliente;

import javax.ejb.Stateless;
import javax.ejb.LocalBean;

/**
 *
 * @author 30917921
 */
@Stateless
@LocalBean
public class BeanCliente implements InterCliente {

    public String setName(String nome) {
        return nome;
    }

    @Override
    public String setEmail(String email) {
        return email;
    }

    @Override
    public int setCod_Cli(int cod_cli) {
        return cod_cli;
    }

    @Override
    public int setRg(int rg) {
        return rg;
    }
}
