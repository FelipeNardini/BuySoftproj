/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package clientejava;

import Cliente.InterCliente;
import javax.naming.InitialContext;
import javax.naming.NamingException;

/**
 *
 * @author 30917921
 */
public class ClienteJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {



    try {
      
      //Método que faz o lookup para encontrar o EJB
      InitialContext ctx = new InitialContext();
      InterCliente ejb = (InterCliente) ctx.lookup("Cliente.InterCliente");

      System.out.println(ejb.setCod_Cli(1));
      System.out.println(ejb.setEmail("teste@hotmail.com"));
      System.out.println(ejb.setName("rafa"));
      System.out.println(ejb.setRg(111));

    } catch (NamingException ex) {
      ex.printStackTrace();
      System.out.println("Não encontrou o EJB.");
    } catch (Exception ex) {
      ex.printStackTrace();
      System.out.println(ex.getMessage());
    }
  }
}
