/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Projeto;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author 30917921
 */
public class Cliente {
    int cod_cli;
    String nome_cli;
    Date data_Nasc = new Date();
    String email;
    int rg;
    int cpf;
    
    SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
}
