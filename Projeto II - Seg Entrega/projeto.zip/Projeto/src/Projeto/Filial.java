/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Projeto;

/**
 *
 * @author 30917921
 */
public class Filial {
    int cod_filial;
    String cidade;
    String uf;
}
