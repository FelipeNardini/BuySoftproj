/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Projeto;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author 30917921
 */
public class Pedido {

    public static void main(String args[]) {

        int cod_ped;

        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");

        Date dataPedido = new Date();
        Calendar dataEntrega = Calendar.getInstance();

        dataEntrega.setTime(new java.util.Date());
        dataEntrega.add(Calendar.DAY_OF_MONTH, 3);

        System.out.println(format.format(dataPedido));
        System.out.println(format.format(dataEntrega.getTimeInMillis()));
    }
}
