/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Projeto;

/**
 *
 * @author 30917921
 */
public class Estoque {
    int cod_Estoque;
    int quantidade;
}
