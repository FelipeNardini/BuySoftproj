/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Projeto;

/**
 *
 * @author 30917921
 */
public class Produto {
    int cod_prod;
    int quantidade;
    String descricao;
    double valor_Unit;
}
